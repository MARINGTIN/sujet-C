/*独立的字典
 le dictionnaire
*/
char *dictionnaire[77] = {
  "NULL",// when there is no matching word, print NULL
  "aller", "avoir", "absence","bonjour", "boire",
  "constant", "cascade", "capitale", "changer", "total",
  "dehors", "habiter", "temps", "repas", "marque",
  "enfin", "statues", "sourire", "heure", "heureux",
  "bruit", "joyeux", "anniversaire", "fatiguer", "proposer",
  "ruses", "revoir", "chemin", "savoir", "demander",
  "murmurer", "cadeau", "combien", "pomme", "terre",
  "nouvelle", "novembre", "arbre", "affairer", "monsieur",
  "elle", "il", "pays", "pouvoir", "dans",
  "nous", "vous", "invitatioin", "vacances", "vouloir",
  "zoo", "soupe", "appartement", "forme", "grand",
  "maladie", "loin", "hasard", "lever", "queue",
  "content", "jardin", "voiture", "argent", "calme",
  "gene","sans","sauf","test","lain",
  "boite","raser","ferme","signe","tasse",
  "ee"//just for test
};
