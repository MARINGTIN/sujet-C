#pragma once
extern void quit(Widget, void *);
extern void consonne(Widget, void *);
extern void voyelle(Widget, void *);
extern void jouer(Widget, void *);
extern void fraude(Widget, void *);

