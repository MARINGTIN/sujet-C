extern void init_display(int, char *[], void *);
extern Widget ZoneSaisie0;
extern Widget ZoneSaisie1;
extern Widget ZoneSaisie2;
extern Widget ZoneSaisie3;
extern Widget ZoneSaisie4;
extern Widget ZoneSaisie5;
extern Widget ZoneSaisie6;
